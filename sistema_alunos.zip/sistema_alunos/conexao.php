<?php 
    define ('HOST', 'localhost');
    define ('USER', 'root');
    define('PASS', '');
    define('BASE', 'sistema');
    $conn = new MySQLi(HOST, USER, PASS, BASE);

    ?>